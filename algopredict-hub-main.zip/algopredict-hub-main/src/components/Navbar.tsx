import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { LogOut, Wallet } from "lucide-react";
import logo from "@/assets/algopred-logo.png";

const Navbar = () => {
  const { user, logout } = useAuth();

  return (
    <nav className="glass border-b border-border/50 sticky top-0 z-50">
      <div className="container flex items-center justify-between h-16">
        <div className="flex items-center gap-3">
          <img src={logo} alt="AlgoPred" width={36} height={36} />
          <span className="font-heading font-bold text-xl text-gradient">AlgoPred</span>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" className="border-primary/30 text-primary hover:bg-primary/10">
            <Wallet className="w-4 h-4 mr-2" />
            Connect Pera Wallet
          </Button>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground hidden sm:inline">
              {user?.username}
            </span>
            <Button variant="ghost" size="icon" onClick={logout} className="text-muted-foreground hover:text-foreground">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
