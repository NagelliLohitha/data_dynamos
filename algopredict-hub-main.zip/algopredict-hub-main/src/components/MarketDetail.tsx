import { useState } from "react";
import { Market, generateOrderBook } from "@/data/markets";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

interface Props {
  market: Market;
  onBack: () => void;
}

const MarketDetail = ({ market, onBack }: Props) => {
  const [side, setSide] = useState<"yes" | "no">("yes");
  const [amount, setAmount] = useState("");
  const orderBook = generateOrderBook(market.yesPrice);

  const handleTrade = () => {
    if (!amount || +amount <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    toast.success(`Order placed: ${side.toUpperCase()} ${amount} ALGO on "${market.title}"`);
    setAmount("");
  };

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Markets
      </button>

      <div className="glass rounded-xl p-6">
        <div className="flex items-start justify-between mb-2">
          <span className="text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary">{market.category}</span>
          <span className="text-xs text-muted-foreground">Ends: {market.endDate}</span>
        </div>
        <h2 className="text-2xl font-heading font-bold text-foreground mb-1">{market.title}</h2>
        <p className="text-sm text-muted-foreground">Volume: {market.volume}</p>
      </div>

      {/* Chart */}
      <div className="glass rounded-xl p-6">
        <h3 className="font-heading font-semibold text-foreground mb-4">Price History</h3>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={market.chartData}>
            <defs>
              <linearGradient id="yesGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(145 63% 49%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(145 63% 49%)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="noGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(0 72% 55%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(0 72% 55%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(222 30% 18%)" />
            <XAxis dataKey="time" tick={{ fill: "hsl(215 20% 55%)", fontSize: 11 }} tickLine={false} axisLine={false} />
            <YAxis domain={[0, 100]} tick={{ fill: "hsl(215 20% 55%)", fontSize: 11 }} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={{ background: "hsl(222 47% 9%)", border: "1px solid hsl(222 30% 18%)", borderRadius: "8px", color: "hsl(210 40% 96%)" }} />
            <Area type="monotone" dataKey="yes" stroke="hsl(145 63% 49%)" fill="url(#yesGrad)" strokeWidth={2} name="Yes" />
            <Area type="monotone" dataKey="no" stroke="hsl(0 72% 55%)" fill="url(#noGrad)" strokeWidth={2} name="No" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Order Book */}
        <div className="glass rounded-xl p-6">
          <h3 className="font-heading font-semibold text-foreground mb-4">Order Book</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-muted-foreground flex justify-between mb-2 px-1">
                <span>Price</span><span>Size</span>
              </div>
              {orderBook.bids.map((b, i) => (
                <div key={i} className="flex justify-between text-xs py-1 px-1 relative">
                  <div className="absolute inset-0 bg-success/10 rounded" style={{ width: `${(b.total / orderBook.bids[orderBook.bids.length - 1].total) * 100}%` }} />
                  <span className="text-success relative z-10">{b.price}¢</span>
                  <span className="text-foreground relative z-10">{b.size}</span>
                </div>
              ))}
            </div>
            <div>
              <div className="text-xs text-muted-foreground flex justify-between mb-2 px-1">
                <span>Price</span><span>Size</span>
              </div>
              {orderBook.asks.map((a, i) => (
                <div key={i} className="flex justify-between text-xs py-1 px-1 relative">
                  <div className="absolute inset-0 bg-destructive/10 rounded right-0" style={{ width: `${(a.total / orderBook.asks[orderBook.asks.length - 1].total) * 100}%` }} />
                  <span className="text-destructive relative z-10">{a.price}¢</span>
                  <span className="text-foreground relative z-10">{a.size}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Trade panel */}
        <div className="glass rounded-xl p-6">
          <h3 className="font-heading font-semibold text-foreground mb-4">Place Order</h3>
          <div className="flex rounded-lg bg-muted p-1 mb-4">
            <button
              onClick={() => setSide("yes")}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${side === "yes" ? "bg-success text-success-foreground" : "text-muted-foreground"}`}
            >
              Yes ({market.yesPrice}¢)
            </button>
            <button
              onClick={() => setSide("no")}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${side === "no" ? "bg-destructive text-destructive-foreground" : "text-muted-foreground"}`}
            >
              No ({market.noPrice}¢)
            </button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-sm text-muted-foreground">Amount (ALGO)</label>
              <Input
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
                className="mt-1 bg-muted border-border"
              />
            </div>
            {amount && +amount > 0 && (
              <div className="text-sm text-muted-foreground space-y-1">
                <div className="flex justify-between">
                  <span>Shares</span>
                  <span className="text-foreground">{(+amount / (side === "yes" ? market.yesPrice : market.noPrice) * 100).toFixed(1)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Potential return</span>
                  <span className="text-success">{(+amount / (side === "yes" ? market.yesPrice : market.noPrice) * 100).toFixed(2)} ALGO</span>
                </div>
              </div>
            )}
            <Button onClick={handleTrade} className="w-full font-heading font-semibold glow-primary">
              Buy {side.toUpperCase()}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketDetail;
