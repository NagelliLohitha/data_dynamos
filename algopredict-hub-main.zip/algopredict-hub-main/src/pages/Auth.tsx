import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import logo from "@/assets/algopred-logo.png";

const Auth = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, signup } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignUp) {
      if (!email || !username || !password) {
        toast.error("All fields are required");
        return;
      }
      if (password.length < 6) {
        toast.error("Password must be at least 6 characters");
        return;
      }
      const ok = signup(email, username, password);
      if (!ok) toast.error("Email already registered");
      else toast.success("Welcome to AlgoPred!");
    } else {
      if (!email || !password) {
        toast.error("Email and password required");
        return;
      }
      const ok = login(email, password);
      if (!ok) toast.error("Invalid credentials");
      else toast.success("Welcome back!");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background relative overflow-hidden">
      {/* Ambient glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-secondary/5 blur-3xl" />

      <div className="glass rounded-2xl p-8 w-full max-w-md mx-4 relative z-10">
        <div className="flex flex-col items-center mb-8">
          <img src={logo} alt="AlgoPred" width={72} height={72} className="mb-4" />
          <h1 className="text-3xl font-heading font-bold text-gradient">AlgoPred</h1>
          <p className="text-muted-foreground text-sm mt-1">Decentralized Prediction Market on Algorand</p>
        </div>

        {/* Tab switcher */}
        <div className="flex rounded-lg bg-muted p-1 mb-6">
          <button
            onClick={() => setIsSignUp(false)}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${!isSignUp ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            Sign In
          </button>
          <button
            onClick={() => setIsSignUp(true)}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${isSignUp ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            Sign Up
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email" className="text-foreground">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-1 bg-muted border-border focus:ring-primary"
            />
          </div>

          {isSignUp && (
            <div>
              <Label htmlFor="username" className="text-foreground">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="Choose a username"
                className="mt-1 bg-muted border-border focus:ring-primary"
              />
            </div>
          )}

          <div>
            <Label htmlFor="password" className="text-foreground">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              className="mt-1 bg-muted border-border focus:ring-primary"
            />
          </div>

          <Button type="submit" className="w-full glow-primary font-heading font-semibold text-base py-5">
            {isSignUp ? "Create Account" : "Sign In"}
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
          <button onClick={() => setIsSignUp(!isSignUp)} className="text-primary hover:underline font-medium">
            {isSignUp ? "Sign In" : "Sign Up"}
          </button>
        </p>
      </div>
    </div>
  );
};

export default Auth;
