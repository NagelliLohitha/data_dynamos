import { useAuth } from "@/contexts/AuthContext";
import Auth from "@/pages/Auth";
import Dashboard from "@/pages/Dashboard";

const Index = () => {
  const { user } = useAuth();
  return user ? <Dashboard /> : <Auth />;
};

export default Index;
