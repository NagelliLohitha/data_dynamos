import { useState } from "react";
import { markets, categories, Market } from "@/data/markets";
import MarketCard from "@/components/MarketCard";
import MarketDetail from "@/components/MarketDetail";
import Navbar from "@/components/Navbar";
import { Search, BarChart3, Users, Zap } from "lucide-react";
import { Input } from "@/components/ui/input";

const Dashboard = () => {
  const [selectedMarket, setSelectedMarket] = useState<Market | null>(null);
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = markets.filter(m => {
    const matchCat = activeCategory === "All" || m.category === activeCategory;
    const matchSearch = m.title.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container py-8">
        {selectedMarket ? (
          <MarketDetail market={selectedMarket} onBack={() => setSelectedMarket(null)} />
        ) : (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                { icon: BarChart3, label: "Total Markets", value: "142", color: "text-primary" },
                { icon: Zap, label: "24h Volume", value: "12.4M ALGO", color: "text-warning" },
                { icon: Users, label: "Active Traders", value: "3,847", color: "text-secondary" },
                { icon: BarChart3, label: "TVL", value: "28.6M ALGO", color: "text-success" },
              ].map((stat, i) => (
                <div key={i} className="glass rounded-xl p-4">
                  <stat.icon className={`w-5 h-5 ${stat.color} mb-2`} />
                  <p className="text-2xl font-heading font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Search + filters */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search markets..."
                  className="pl-10 bg-muted border-border"
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3 py-1.5 text-sm rounded-lg transition-all font-medium ${
                      activeCategory === cat
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Markets grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map(m => (
                <MarketCard key={m.id} market={m} onClick={setSelectedMarket} />
              ))}
            </div>

            {filtered.length === 0 && (
              <p className="text-center text-muted-foreground py-12">No markets found.</p>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default Dashboard;
