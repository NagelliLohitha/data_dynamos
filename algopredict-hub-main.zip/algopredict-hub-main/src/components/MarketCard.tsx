import { Market } from "@/data/markets";
import { TrendingUp, TrendingDown, Clock } from "lucide-react";

interface Props {
  market: Market;
  onClick: (m: Market) => void;
}

const MarketCard = ({ market, onClick }: Props) => {
  const isUp = market.yesPrice > 50;
  return (
    <div
      onClick={() => onClick(market)}
      className="glass rounded-xl p-5 cursor-pointer hover:border-primary/40 transition-all hover:glow-primary group"
    >
      <div className="flex items-start justify-between mb-3">
        <span className="text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary">{market.category}</span>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          {market.endDate}
        </div>
      </div>
      <h3 className="font-heading font-semibold text-foreground mb-4 group-hover:text-primary transition-colors leading-snug">
        {market.title}
      </h3>
      <div className="flex items-center justify-between">
        <div className="flex gap-3">
          <div className="flex items-center gap-1">
            <TrendingUp className="w-4 h-4 text-success" />
            <span className="text-success font-semibold">{market.yesPrice}¢</span>
            <span className="text-xs text-muted-foreground">Yes</span>
          </div>
          <div className="flex items-center gap-1">
            <TrendingDown className="w-4 h-4 text-destructive" />
            <span className="text-destructive font-semibold">{market.noPrice}¢</span>
            <span className="text-xs text-muted-foreground">No</span>
          </div>
        </div>
        <span className="text-xs text-muted-foreground">Vol: {market.volume}</span>
      </div>
      {/* Mini progress bar */}
      <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full bg-gradient-to-r from-success to-primary transition-all" style={{ width: `${market.yesPrice}%` }} />
      </div>
    </div>
  );
};

export default MarketCard;
