import React, { createContext, useContext, useState, useCallback } from "react";

interface User {
  email: string;
  username: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  signup: (email: string, username: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be within AuthProvider");
  return ctx;
};

interface StoredUser {
  email: string;
  username: string;
  password: string;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  const getUsers = (): StoredUser[] => {
    try {
      return JSON.parse(localStorage.getItem("algopred_users") || "[]");
    } catch {
      return [];
    }
  };

  const signup = useCallback((email: string, username: string, password: string): boolean => {
    const users = getUsers();
    if (users.find(u => u.email === email)) return false;
    users.push({ email, username, password });
    localStorage.setItem("algopred_users", JSON.stringify(users));
    setUser({ email, username });
    return true;
  }, []);

  const login = useCallback((email: string, password: string): boolean => {
    const users = getUsers();
    const found = users.find(u => u.email === email && u.password === password);
    if (!found) return false;
    setUser({ email: found.email, username: found.username });
    return true;
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
