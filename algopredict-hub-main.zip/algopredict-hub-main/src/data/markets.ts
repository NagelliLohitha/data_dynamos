export interface Market {
  id: string;
  title: string;
  category: string;
  yesPrice: number;
  noPrice: number;
  volume: string;
  endDate: string;
  resolved: boolean;
  chartData: { time: string; yes: number; no: number }[];
}

const generateChart = (base: number) => {
  const data = [];
  let val = base;
  for (let i = 30; i >= 0; i--) {
    val = Math.max(5, Math.min(95, val + (Math.random() - 0.5) * 8));
    const d = new Date();
    d.setDate(d.getDate() - i);
    data.push({ time: d.toLocaleDateString("en", { month: "short", day: "numeric" }), yes: Math.round(val), no: Math.round(100 - val) });
  }
  return data;
};

export const markets: Market[] = [
  { id: "1", title: "Will Bitcoin exceed $150K by Dec 2026?", category: "Crypto", yesPrice: 62, noPrice: 38, volume: "2.4M ALGO", endDate: "Dec 31, 2026", resolved: false, chartData: generateChart(62) },
  { id: "2", title: "Will Algorand TVL surpass $1B by Q3 2026?", category: "DeFi", yesPrice: 45, noPrice: 55, volume: "890K ALGO", endDate: "Sep 30, 2026", resolved: false, chartData: generateChart(45) },
  { id: "3", title: "US Fed rate cut before July 2026?", category: "Economics", yesPrice: 73, noPrice: 27, volume: "1.8M ALGO", endDate: "Jul 1, 2026", resolved: false, chartData: generateChart(73) },
  { id: "4", title: "SpaceX Starship orbital flight success in 2026?", category: "Science", yesPrice: 81, noPrice: 19, volume: "560K ALGO", endDate: "Dec 31, 2026", resolved: false, chartData: generateChart(81) },
  { id: "5", title: "Ethereum ETF approval in 2026?", category: "Crypto", yesPrice: 55, noPrice: 45, volume: "3.1M ALGO", endDate: "Dec 31, 2026", resolved: false, chartData: generateChart(55) },
  { id: "6", title: "Global AI regulation framework by 2026?", category: "Politics", yesPrice: 34, noPrice: 66, volume: "420K ALGO", endDate: "Dec 31, 2026", resolved: false, chartData: generateChart(34) },
];

export const categories = ["All", "Crypto", "DeFi", "Economics", "Science", "Politics"];

export interface OrderBookEntry {
  price: number;
  size: number;
  total: number;
}

export const generateOrderBook = (midPrice: number): { bids: OrderBookEntry[]; asks: OrderBookEntry[] } => {
  const bids: OrderBookEntry[] = [];
  const asks: OrderBookEntry[] = [];
  let bidTotal = 0, askTotal = 0;
  for (let i = 0; i < 8; i++) {
    const bSize = Math.round(100 + Math.random() * 500);
    bidTotal += bSize;
    bids.push({ price: +(midPrice - (i + 1) * 0.5).toFixed(1), size: bSize, total: bidTotal });
    const aSize = Math.round(100 + Math.random() * 500);
    askTotal += aSize;
    asks.push({ price: +(midPrice + (i + 1) * 0.5).toFixed(1), size: aSize, total: askTotal });
  }
  return { bids, asks };
};
